import { ViewStatus, Type, UiState, AppState, DataState } from '../app.state';
import uiReducer from './reducers/step.ui.reducer'
import dataReducer from './reducers/step.data.reducer'

export const initialUiState: UiState = {
  viewStatus: ViewStatus.Initial,
  dataType: Type.Step
}

export const initialDataState: DataState = {
  title: "test",
  journeyId: "",
  section: [],
}

export const initialState: AppState = {
  uiState: initialUiState,
  dataState: initialDataState,
};

export default function steppAppReducer(state = initialState, action) {

  return {
    uiState: uiReducer(state.uiState , action),
    dataState: dataReducer(state.dataState, action)
  }
}
