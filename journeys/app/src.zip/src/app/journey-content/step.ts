export interface Step {
  title: string,
  section: string,
}
