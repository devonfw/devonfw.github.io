export interface Journey {
  id: number;
  title: string;
  sections: [] ;
}
