﻿namespace Devon4Net.Application.Keycloak.Model
{
    public class Student : Person
    {
        public List<string> Subjects { get; set; }
    }
}
