export enum ViewStatus {
    Initial = 'INITIAL',
    Loading = 'LOADING',
    Success = 'SUCCESS',
    Failure = 'FAILURE',
}
export enum Type {
  Journey = 'JOURNEY',
  Step = 'STEP',
}

export interface DataState {
  title: string;
  journeyId: string;
  section: [];
}
export interface UiState {
  viewStatus: ViewStatus;
  dataType: Type;
  errorMessage?: string;
}

export interface AppState {
  uiState: UiState;
  dataState: DataState;
}

